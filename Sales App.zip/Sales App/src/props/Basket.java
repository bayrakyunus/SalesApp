package props;

public class Basket {

    private int bid;
    private int bprid;
    private double bprprice;
    private int bstatu;
    private int bpid;
    private String bdate;

    public int getBid() {
        return bid;
    }

    public void setBid(int bid) {
        this.bid = bid;
    }

    public int getBprid() {
        return bprid;
    }

    public void setBprid(int bprid) {
        this.bprid = bprid;
    }
    
    public double getBprprice() {
        return bprprice;
    }

    public void setBprprice(double bprprice) {
        this.bprprice = bprprice;
    }

    public int getBstatu() {
        return bstatu;
    }

    public void setBstatu(int bstatu) {
        this.bstatu = bstatu;
    }

    public int getBpid() {
        return bpid;
    }

    public void setBpid(int bpid) {
        this.bpid = bpid;
    }

    public String getBdate() {
        return bdate;
    }

    public void setBdate(String bdate) {
        this.bdate = bdate;
    }
}
