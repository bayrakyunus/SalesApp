package props;

public class User {

    private int uid;
    private String uname;
    private String uusername;
    private int ustatu;
    private int upid;

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getUusername() {
        return uusername;
    }

    public void setUusername(String uusername) {
        this.uusername = uusername;
    }

    public int getUstatu() {
        return ustatu;
    }

    public void setUstatu(int ustatu) {
        this.ustatu = ustatu;
    }

    public int getUpid() {
        return upid;
    }

    public void setUpid(int upid) {
        this.upid = upid;
    }

}
